   <div class="content-wrapper">

  <section class="content-header">
    <h1 class="text-center">BD NEWS 24 Dashboard</h1>
    <hr>
  </section>

  <!-- 
  <div class="container">
    <div class="row">

<a href="<?=base_url()?>Manage_items">
        <div class="col-md-4 col-md-offset-1 single-box" style=" background: #17B978;padding: 20px;border-radius: .15rem;">

        <p class="text-center" style="color: white;font-size: 24px;">Items</p> 
        <p  class="text-center" style="color: white;font-size: 20px;"><?=$total_items?></p> 

      </div>
      
</a>
 <a href="<?=base_url()?>Categories">
        <div class="col-md-4 col-md-offset-1 single-box" style=" background: #17B978;padding: 20px;border-radius: .15rem;">

        <p class="text-center" style="color: white;font-size: 24px;">Cateogries</p> 
        <p  class="text-center" style="color: white;font-size: 20px;"><?=$total_categories?></p> 

      </div>
      
 </a>
    </div>
  </div>

  <div class="container">
    <div class="row">

<a href="<?=base_url()?>Order/delivered_orders">
        <div class="col-md-4 col-md-offset-1 single-box" style=" background: #17B978;padding: 20px;border-radius: .15rem;">
        
        <p class="text-center" style="color: white;font-size: 24px;">Delivered Orders</p> 
        <p  class="text-center" style="color: white;font-size: 20px;"><?=$delivered_orders?></p> 
        
      </div>
</a>

<a href="<?=base_url()?>Users/messages">
      <div class="col-md-4 col-md-offset-1 single-box" style=" background: #17B978;padding: 20px;border-radius: .15rem;">
        
        <p class="text-center" style="color: white;font-size: 24px;">Messages</p> 
        <p  class="text-center" style="color: white;font-size: 20px;"><?=$total_contact?></p> 
        
      </div>
    </div>
  </div>
</a>
    
  <div class="container">
    <div class="row">
      <a href="<?=base_url()?>Users/index">
      <div class="col-md-4 col-md-offset-1 single-box" style=" background: #17B978;padding: 20px;border-radius: .15rem;">
        
        <p class="text-center" style="color: white;font-size: 24px;">Users</p> 
        <p  class="text-center" style="color: white;font-size: 20px;"><?=$total_users?></p> 
        
      </div>
    </a>

    <a href="<?=base_url()?>Order/pending_orders">
      <div class="col-md-4 col-md-offset-1 single-box" style=" background: #17B978;padding: 20px;border-radius: .15rem;">
        
        <p class="text-center" style="color: white;font-size: 24px;">Pending Orders</p> 
        <p  class="text-center" style="color: white;font-size: 20px;"><?=$pending_orders?></p> 
        
      </div>
    </a>
    </div>
  </div> -->
           </div>

      <style type="text/css">
  .container{
    margin-bottom: 30px;
  }
</style>